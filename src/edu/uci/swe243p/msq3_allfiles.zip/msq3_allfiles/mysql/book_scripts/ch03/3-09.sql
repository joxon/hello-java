SELECT vendor_city, vendor_state
FROM vendors
ORDER BY vendor_city;

SELECT DISTINCT vendor_city, vendor_state
FROM vendors
ORDER BY vendor_city;