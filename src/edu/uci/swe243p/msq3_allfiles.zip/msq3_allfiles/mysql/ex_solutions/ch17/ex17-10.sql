SET GLOBAL  general_log = ON;

SELECT @@general_log;