SELECT *
FROM open_items_summary
LIMIT 5