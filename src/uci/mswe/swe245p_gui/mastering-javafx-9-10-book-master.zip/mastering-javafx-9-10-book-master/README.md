The book has been published! 
 * Amazon: https://www.amazon.com/Mastering-JavaFX-advanced-visually-applications/dp/1788293827/
 * Packt: https://www.packtpub.com/web-development/mastering-javafx-10

# Mastering JavaFX 10

 * Chapter 1: Stages, Scenes and Layout 
 * Chapter 2: Building Blocks: Shapes, Text and Controls 
 * Chapter 3: Connecting Pieces: Binding 
 * Chapter 4: FXML 
 * Chapter 5: Animation 
 * Chapter 6: Styling application with CSS 
 * Chapter 7: Building Dynamic UI 
 * Chapter 8: Effects 
 * Chapter 9: Media and WebView 
 * Chapter 10: Advanced Controls and Charts 
 * Chapter 11: Packaging with Java9 Jigsaw 
 * Chapter 12: 3D at a glance 
 * Chapter 13: What's Next?
